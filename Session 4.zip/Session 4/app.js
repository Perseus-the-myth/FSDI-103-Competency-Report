let hunger=50;
let happiness=50;
let energy=50;

function displayValues(){
    document.getElementById("petHunger").innerHTML=`${hunger}`;
    document.getElementById("petHappiness").innerHTML=`${happiness}`;
    document.getElementById("petEnergy").innerHTML=`${energy}`;

}
function feed(){
    if((hunger>0 && hunger<100) && (happiness>0 && happiness<100)){
    //increasing happiness and decreasing hunger
        happiness=happiness+10;
        hunger=hunger-10;
        console.log(happiness,hunger);
        displayValues();
}
}

function pet(){
    if((happiness>0 && happiness<100)){
    //increase happiness
    happiness=happiness+10;
    console.log(happiness,hunger);
    displayValues();
}
}
function play(){
    if((happiness>0 && energy<100)){
    //increase happiness and decrease energy
    happiness=happiness+10;
    energy=energy-10;
    console.log(happiness,hunger);
    displayValues();
}
}

displayValues();